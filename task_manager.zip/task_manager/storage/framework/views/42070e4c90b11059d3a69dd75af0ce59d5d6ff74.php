<?php

?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />

</head>
<body>



<form action="" class="btn-submit" method="POST">


    <input type="hidden" id="id" value="<?php echo e($t['id']); ?>">
	
    title:<input type="text" id="title" value="<?php echo e($t['title']); ?>"><br>
    desc:<input type="text" id="desc" value='<?php echo e($t->desc); ?>'><br>
    
	priority:<select id="priority">
      
      <option value=''>select</option>
      <option value="low" <?php if($t->priority=='low'): ?> <?php echo e('selected'); ?> <?php endif; ?> >low</option>
      <option value="medium" <?php if($t->priority=='medium'): ?> <?php echo e('selected'); ?> <?php endif; ?> >medium</option>
      <option value="high" <?php if($t->priority=='high'): ?> <?php echo e('selected'); ?> <?php endif; ?> >high</option>
     
    </select>

    <br>

    <button id='saveBtn' >UPDATE</button>
  
</form>



    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>  
<script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>

   <script>
    $(document).ready(function () {
		// alert('ddd')
		
		 $.ajaxSetup({
			headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
			}
		});
    
		$("#saveBtn").on("click",function(e){
			e.preventDefault();

			var id = $('#id').val();
			var title = $('#title').val();
			var desc = $('#desc').val();
			var time = $('#time').val();
			var priority = $('#priority').val();
		  // alert(priority);
			
			$.ajax({
				url: "update/"+id,
				method:"POST",
				data:{
					title:title,
					desc:desc,
					time:time,
					priority:priority,		
				},
				success:function(response){
					  window.location.href = "<?php echo e(url('/')); ?>";
				   }
				   
			})

		});
		
		$('#form').validate({ // initialize the plugin
        rules: {
            title: {
                required: true
            },
            desc: {
                required: true,
            },
			priority: {
                required: true,
            },
			time: {
                required: true,
            },
        }
    });
	  
	})
</script>

</body>
</html>
<?php /**PATH E:\xampp\htdocs\task_manager\resources\views/editTask.blade.php ENDPATH**/ ?>
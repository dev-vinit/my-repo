<html>
<head>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />

	
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
	<!-- VENDOR CSS -->
	<link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" href="assets/vendor/font-awesome/css/font-awesome.min.css">
	<link rel="stylesheet" href="assets/vendor/linearicons/style.css">
	<link rel="stylesheet" href="assets/vendor/chartist/css/chartist-custom.css">
	<!-- MAIN CSS -->
	<link rel="stylesheet" href="assets/css/main.css">
	<!-- FOR DEMO PURPOSES ONLY. You should remove this in your project -->
	<link rel="stylesheet" href="assets/css/demo.css">
	<!-- GOOGLE FONTS -->
	<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700" rel="stylesheet">
	<!-- ICONS -->
	<link rel="apple-touch-icon" sizes="76x76" href="assets/img/apple-icon.png">
	<link rel="icon" type="image/png" sizes="96x96" href="assets/img/favicon.png">
</head>
<body>


<div class="row">
	<div class="col-md-6">
		<!-- RECENT PURCHASES -->
		<div class="panel">
			<div class="panel-heading">
				<h3 class="panel-title">Tasks List</h3>
				<div class="right">
					
				</div>
			</div>
			<div class="panel-body no-padding">
			
			<form action="search">
				<div class="form-group">
					<input type='text' name='search' minlength="3"  placeholder='search by title'>
				</div>
			 <input type='submit' class="btn btn-primary btn" value='search'>
			</form>
								
								
			<table class='table' align="center" border="2">
                <thead>
                <tr align="center">
                    <td>title</td>
                    <td>desc</td>
                    <td>due date</td>
                    <td>priority</td>
                
                    <td colspan="1" align="center">ACTION</td>
                    <td colspan="1" align="center">status</td>
                </tr>    
				</thead>

                <?php
                foreach($t as $f)
                {
                ?>
				<tbody>
                <tr align="center">     
                    <td> <?php if($f->done==1): ?> <?php echo "<strike>".$f->title."</strike>";?> <?php else: ?> <?php echo $f->title;?> <?php endif; ?> </td>
                    <td><?php echo $f->desc;?></td>
                    <td><?php echo $f->time;?></td>
                    <td><?php echo $f->priority;?></td>
                
                    <td><a href='' onclick="return confirm('Are you sure?')" class='remove-item' id='<?php echo $f->id;?>'> delete </a></td>
                    <td><a class='done' id="<?php echo e($f->id); ?>" data-value="<?php echo e($f->done); ?>" href=""> <?php if($f->done==1): ?> <?php echo e('done'); ?> <?php else: ?> <?php echo e('not done'); ?> <?php endif; ?> </a></td>
                    
                </tr>
				</tbody>

                <?php
                }
                ?>
            </table>
			
			<?php echo $t->render(); ?>

			</div>
								
		</div>
							<!-- END RECENT PURCHASES -->
		</div>
		
		
			<div class="col-md-6">
				<!-- MULTI CHARTS -->
				<div class="panel">
					<div class="panel-heading">
						<h3 class="panel-title">Add Task</h3>
						<div class="right">
							
						</div>
					</div>
					<div class="panel-body">
								
								
								
								
			<form action="save" class="form-auth-small" id='form' method="POST">
				<?php echo csrf_field(); ?>
					<?php if($errors->any()): ?>
					  <ul>
						<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						  <li style="color: red"><?php echo e($error); ?></li>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					  </ul>
					<?php endif; ?>    
					
					<div class="form-group">
						title:<input class="form-control" type="text" id="title" name="title">
					</div>
					<div class="form-group">
						desc:<input class="form-control" type="text" id="desc" name="desc">
					</div>
					<div class="form-group">
						time:<input class="form-control" type="datetime-local" id="time" name="time">
					</div>
					<div class="form-group">
						priority:<select id="priority" class="form-control" name="priority">

					  <option value=''>select</option>
					  <option value="low">low</option>
					  <option value="medium">medium</option>
					  <option value="high">high</option>
					 
					</select>
					
					</div>

					<button id='saveBtn' class="btn btn-primary btn">Add</button>
  
			</form>
									
								
						<div id="visits-trends-chart" class="ct-chart"></div>
					</div>
				</div>
				<!-- END MULTI CHARTS -->
			</div>
</div>


    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>  
<script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>

   <script>
    $(document).ready(function () {
		
		jQuery.validator.addMethod("lettersonly", function(value, element) {
			return this.optional(element) || /^[a-zA-Z ]*$/.test(value);
		}, "letters and space only please");
		
		$('#form').validate({ 
			rules: {
				title: {
					required: true,
					lettersonly: true,
				},
				desc: {
					required: true,
					maxlength: 255
				},
				priority: {
					required: true,
				},
				time: {
					required: true,
				},
			}
		});
		
		 $.ajaxSetup({
			headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
			}
		});
    
		$("#form").on("submit",function(e){
			e.preventDefault();

			var title = $('#title').val();
			var desc = $('#desc').val();
			var time = $('#time').val();
			var priority = $('#priority').val();
		
			$.ajax({
				url: "save",
				method:"POST",
				data:{
					title:title,
					desc:desc,
					time:time,
					priority:priority,		
				},
				success:function(response){
					if(response.success){
						  alert(response.message)
							window.location.href = "<?php echo e(url('/')); ?>";
					  }else{
						  alert("Error")
					  }
				   }
				   
			})

		});
	
	  
	  
	  $(".remove-item").on("click",function(e){
			e.preventDefault();
			var id=$(this).attr('id');
		
			$.ajax({
				url: "delete/"+id,
				success:function(response){
					  window.location.href = "<?php echo e(url('/')); ?>";
				   }
			})

		});
		
		$(".done").on("click",function(e){
			e.preventDefault();
			
			var id=$(this).attr('id');

			 var val=$(this).data("value");
			var id=$(this).attr('id');
		
			$.ajax({
				url: "done/"+id,
				method:"POST",
				data:{
					val:val,
				},
				success:function(response){
					  window.location.href = "<?php echo e(url('/')); ?>";
				   }
			})

		});
		
		
	  
	})
</script>

</body>
</html>
<?php /**PATH E:\xampp\htdocs\task_manager\resources\views/addTask.blade.php ENDPATH**/ ?>
<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\task;
use DB;

class taskController extends Controller
{
	function add(request $request){
		if($request->search){

			$t=task::where('title','like', '%'.$request->search.'%')->orderBy('time','asc')->paginate(3);
			
		}else{
			$t=task::orderBy('time','asc')->paginate(3);
		}
		return view('addTask',['t'=>$t]);
	}
	
    function save(request $request){
		
		$request->validate([  
        'title'=>'required | regex:/^[a-zA-Z\s]+$/' , 'desc'=>'required | max:255','time'=>'required','priority'=>'required']);  
		
		$obj=new task;
		$obj->title=$request->title;
		$obj->desc=$request->desc;
		$obj->time=$request->time;
		$obj->priority=$request->priority;
		$obj->save();
		
		return response()->json(
            [
                'success' => true,
                'message' => 'Data inserted successfully'
            ]
        );
		
		
	}
	
	function delete($id){
		task::find($id)->delete();
	}
	
	function edit(request $request,$id){

		$t=task::where('id',$id)->first();
		// echo "<pre>";
		// print_r($t);die;
		
		return view('editTask',['t'=>$t]);
	}
	
	function done(request $request,$id){
		if($request->val==0){
			$v=1;
		}else{
			$v=0;
		}
		
		task::where('id',$id)->update(
		['done'=>$v]
		);
		
	}
	
	
	
}
